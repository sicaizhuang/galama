#ifndef __MAIN_H
#define __MAIN_H

#include <REGX51.H>
unsigned char s[]={0x01,0x00};
unsigned char count=0,num=0;

void initTimer();
void display();

void timer_isr() interrupt 1;

#endif 