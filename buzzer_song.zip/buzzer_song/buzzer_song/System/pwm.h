#ifndef __PWM_H
#define __PWM_H

#include "stm32f10x.h"      

#define ARR 1200-1

void PWM_Init(void);                // PWM 初始化：GPIO + TIM2-CH1(PA0)
void PWM_SetCCR(uint16_t Compare);  // 修改占空比（修改 TIM2->CCR1 值）
void PWM_SetPSC(uint16_t Prescaler);// 修改预分频系数（影响频率）
void PWM_SetARR(uint16_t Period);   // 修改自动重装载值（影响频率）

#endif
