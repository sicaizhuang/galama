#ifndef __BUZZER_H
#define __BUZZER_H
#include "stm32f10x.h"
#include "pwm.h"

#define DELAY_TIME 850
#define ZERO_DELAY 10


#define	_C	1  
#define	_D	2  
#define	_E	3  
#define	_F	4  
#define	_G	5  
#define	_A	6
#define	_B	7  
#define	C	8  
#define	D	9  
#define	E	10  
#define	F	11 
#define	G	12 
#define	A	13
#define	B	14
#define	C_	15 
#define	D_	16 
#define	E_	17 
#define	F_	18 
#define	G_	19 
#define	A_	20
#define	B_	21
#define X	22
#define _   23
#define _4  24
#define _8  25
#define _3  26


void Buzzer_Init(void);
void play_note(uint8_t num);
#endif

