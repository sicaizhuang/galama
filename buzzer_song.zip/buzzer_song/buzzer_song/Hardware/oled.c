/*
本代码基于江协科技 OLED 驱动代码开发，并集成了波特律动字体和图形扩展功能。  
- 江协科技代码部分：提供基础的 OLED 初始化和字符显示功能。  
- 波特律动扩展部分：添加了高级绘图函数、中文字体支持以及图形显示功能。  
如需使用中文字模或图形工具，请访问波特律动 LED 取模助手：https://led.baud-dance.com

本代码仅供学习和研究用途。未经版权所有者书面许可，不得用于任何商业用途。  
*/
#include "oled.h"
#include "oled_font.h"
#include "stm32f10x.h"
#include <string.h>
#include <math.h>
#include <stdlib.h>
#include <stdio.h>

#define OLED_W_SCL(x) GPIO_WriteBit(GPIOB, GPIO_Pin_8, (BitAction)(x))
#define OLED_W_SDA(x) GPIO_WriteBit(GPIOB, GPIO_Pin_9, (BitAction)(x))

void OLED_I2C_Init(void) {
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB, ENABLE);
    GPIO_InitTypeDef GPIO_InitStructure;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_OD;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_8 | GPIO_Pin_9;
    GPIO_Init(GPIOB, &GPIO_InitStructure);
    OLED_W_SCL(1); OLED_W_SDA(1);
}

void OLED_I2C_Start(void) {
    OLED_W_SDA(1); OLED_W_SCL(1);
    OLED_W_SDA(0); OLED_W_SCL(0);
}

void OLED_I2C_Stop(void) {
    OLED_W_SDA(0); OLED_W_SCL(1);
    OLED_W_SDA(1);
}

void OLED_I2C_SendByte(uint8_t Byte) {
    for (uint8_t i = 0; i < 8; i++) {
        OLED_W_SDA(Byte & (0x80 >> i));
        OLED_W_SCL(1); OLED_W_SCL(0);
    }
    OLED_W_SCL(1); OLED_W_SCL(0); // 忽略 ACK
}

void OLED_WriteCommand(uint8_t Command) {
    OLED_I2C_Start();
    OLED_I2C_SendByte(0x78);
    OLED_I2C_SendByte(0x00);
    OLED_I2C_SendByte(Command);
    OLED_I2C_Stop();
}

void OLED_WriteData(uint8_t Data) {
    OLED_I2C_Start();
    OLED_I2C_SendByte(0x78);
    OLED_I2C_SendByte(0x40);
    OLED_I2C_SendByte(Data);
    OLED_I2C_Stop();
}

void OLED_SetCursor(uint8_t Y, uint8_t X) {
    OLED_WriteCommand(0xB0 | Y);
    OLED_WriteCommand(0x10 | ((X & 0xF0) >> 4));
    OLED_WriteCommand(0x00 | (X & 0x0F));
}

void OLED_Clear(void) {
    uint8_t i, j;
    for (j = 0; j < 8; j++) {
        OLED_SetCursor(j, 0);
        for (i = 0; i < 128; i++) OLED_WriteData(0x00);
    }
}

void OLED_ShowChar(uint8_t Line, uint8_t Column, char Char) {
    uint8_t i;
    OLED_SetCursor((Line - 1) * 2, (Column - 1) * 8);
    for (i = 0; i < 8; i++) OLED_WriteData(OLED_F8x16[Char - ' '][i]);
    OLED_SetCursor((Line - 1) * 2 + 1, (Column - 1) * 8);
    for (i = 8; i < 16; i++) OLED_WriteData(OLED_F8x16[Char - ' '][i]);
}

void OLED_ShowString(uint8_t Line, uint8_t Column, char *String) {
    uint8_t i;
    for (i = 0; String[i] != '\0'; i++) OLED_ShowChar(Line, Column + i, String[i]);
}

uint32_t OLED_Pow(uint32_t X, uint32_t Y) {
    uint32_t Result = 1;
    while (Y--) Result *= X;
    return Result;
}

void OLED_ShowNum(uint8_t Line, uint8_t Column, uint32_t Number, uint8_t Length) {
    uint8_t i;
    for (i = 0; i < Length; i++) {
        OLED_ShowChar(Line, Column + i, Number / OLED_Pow(10, Length - i - 1) % 10 + '0');
    }
}

void OLED_ShowSignedNum(uint8_t Line, uint8_t Column, int32_t Number, uint8_t Length) {
    uint8_t i; uint32_t Number1;
    if (Number >= 0) { OLED_ShowChar(Line, Column, '+'); Number1 = Number; }
    else { OLED_ShowChar(Line, Column, '-'); Number1 = -Number; }
    for (i = 0; i < Length; i++) {
        OLED_ShowChar(Line, Column + i + 1, Number1 / OLED_Pow(10, Length - i - 1) % 10 + '0');
    }
}

void OLED_ShowHexNum(uint8_t Line, uint8_t Column, uint32_t Number, uint8_t Length) {
    uint8_t i, SingleNumber;
    for (i = 0; i < Length; i++) {
        SingleNumber = Number / OLED_Pow(16, Length - i - 1) % 16;
        OLED_ShowChar(Line, Column + i, SingleNumber < 10 ? SingleNumber + '0' : SingleNumber - 10 + 'A');
    }
}

void OLED_ShowBinNum(uint8_t Line, uint8_t Column, uint32_t Number, uint8_t Length) {
    uint8_t i;
    for (i = 0; i < Length; i++) {
        OLED_ShowChar(Line, Column + i, Number / OLED_Pow(2, Length - i - 1) % 2 + '0');
    }
}

void OLED_Init(void) {
    uint32_t i, j;
    for (i = 0; i < 1000; i++) for (j = 0; j < 1000; j++);
    OLED_I2C_Init();
    OLED_WriteCommand(0xAE);
    OLED_WriteCommand(0x20); OLED_WriteCommand(0x10);
    OLED_WriteCommand(0xB0);
    OLED_WriteCommand(0xC8);
    OLED_WriteCommand(0x00); OLED_WriteCommand(0x10);
    OLED_WriteCommand(0x40);
    OLED_WriteCommand(0x81); OLED_WriteCommand(0xCF);
    OLED_WriteCommand(0xA1);
    OLED_WriteCommand(0xA6);
    OLED_WriteCommand(0xA8); OLED_WriteCommand(0x3F);
    OLED_WriteCommand(0xA4);
    OLED_WriteCommand(0xD3); OLED_WriteCommand(0x00);
    OLED_WriteCommand(0xD5); OLED_WriteCommand(0xF0);
    OLED_WriteCommand(0xD9); OLED_WriteCommand(0x22);
    OLED_WriteCommand(0xDA); OLED_WriteCommand(0x12);
    OLED_WriteCommand(0xDB); OLED_WriteCommand(0x20);
    OLED_WriteCommand(0x8D); OLED_WriteCommand(0x14);
    OLED_Clear();
    OLED_WriteCommand(0xAF);
}

/* ---------------- 波特律动扩展函数（完整） ---------------- */

uint8_t OLED_GRAM[8][128];

void OLED_NewFrame(void) { memset(OLED_GRAM, 0, sizeof(OLED_GRAM)); }

void OLED_ShowFrame(void) {
    for (uint8_t i = 0; i < 8; i++) {
        OLED_WriteCommand(0xB0 + i);
        OLED_WriteCommand(0x00);
        OLED_WriteCommand(0x10);
        for (uint8_t j = 0; j < 128; j++) OLED_WriteData(OLED_GRAM[i][j]);
    }
}

void OLED_SetPixel(uint8_t x, uint8_t y, OLED_ColorMode color) {
    if (x >= 128 || y >= 64) return;
    if (color == OLED_COLOR_NORMAL)
        OLED_GRAM[y / 8][x] |= (1 << (y % 8));
    else
        OLED_GRAM[y / 8][x] &= ~(1 << (y % 8));
}

void OLED_DrawLine(uint8_t x1, uint8_t y1, uint8_t x2, uint8_t y2, OLED_ColorMode color) {
    int dx = abs(x2 - x1), sx = x1 < x2 ? 1 : -1;
    int dy = abs(y2 - y1), sy = y1 < y2 ? 1 : -1;
    int err = dx - dy;
    while (1) {
        OLED_SetPixel(x1, y1, color);
        if (x1 == x2 && y1 == y2) break;
        int e2 = 2 * err;
        if (e2 > -dy) { err -= dy; x1 += sx; }
        if (e2 < dx)  { err += dx; y1 += sy; }
    }
}

void OLED_DrawRectangle(uint8_t x, uint8_t y, uint8_t w, uint8_t h, OLED_ColorMode color) {
    OLED_DrawLine(x, y, x + w, y, color);
    OLED_DrawLine(x, y + h, x + w, y + h, color);
    OLED_DrawLine(x, y, x, y + h, color);
    OLED_DrawLine(x + w, y, x + w, y + h, color);
}

void OLED_DrawFilledRectangle(uint8_t x, uint8_t y, uint8_t w, uint8_t h, OLED_ColorMode color) {
    for (uint8_t i = 0; i <= h; i++) OLED_DrawLine(x, y + i, x + w, y + i, color);
}

void OLED_DrawCircle(uint8_t x, uint8_t y, uint8_t r, OLED_ColorMode color) {
    int16_t a = 0, b = r, di = 3 - (r << 1);
    while (a <= b) {
        OLED_SetPixel(x - b, y - a, color); OLED_SetPixel(x + b, y - a, color);
        OLED_SetPixel(x - a, y + b, color); OLED_SetPixel(x + a, y + b, color);
        OLED_SetPixel(x - a, y - b, color); OLED_SetPixel(x + a, y - b, color);
        OLED_SetPixel(x + b, y + a, color); OLED_SetPixel(x - b, y + a, color);
        a++; if (di < 0) di += 4 * a + 6; else { di += 10 + 4 * (a - b); b--; }
    }
}

void OLED_DrawFilledCircle(uint8_t x, uint8_t y, uint8_t r, OLED_ColorMode color) {
    int16_t a = 0, b = r, di = 3 - (r << 1);
    while (a <= b) {
        for (int16_t i = x - b; i <= x + b; i++) { OLED_SetPixel(i, y + a, color); OLED_SetPixel(i, y - a, color); }
        for (int16_t i = x - a; i <= x + a; i++) { OLED_SetPixel(i, y + b, color); OLED_SetPixel(i, y - b, color); }
        a++; if (di < 0) di += 4 * a + 6; else { di += 10 + 4 * (a - b); b--; }
    }
}

void OLED_DrawEllipse(uint8_t x, uint8_t y, uint8_t a, uint8_t b, OLED_ColorMode color) {
    int xpos = 0, ypos = b, a2 = a * a, b2 = b * b, d = b2 + a2 * (0.25 - b);
    while (a2 * ypos > b2 * xpos) {
        OLED_SetPixel(x + xpos, y + ypos, color); OLED_SetPixel(x - xpos, y + ypos, color);
        OLED_SetPixel(x + xpos, y - ypos, color); OLED_SetPixel(x - xpos, y - ypos, color);
        if (d < 0) { d += b2 * ((xpos << 1) + 3); xpos++; }
        else { d += b2 * ((xpos << 1) + 3) + a2 * (-(ypos << 1) + 2); xpos++; ypos--; }
    }
    d = b2 * (xpos + 0.5) * (xpos + 0.5) + a2 * (ypos - 1) * (ypos - 1) - a2 * b2;
    while (ypos > 0) {
        OLED_SetPixel(x + xpos, y + ypos, color); OLED_SetPixel(x - xpos, y + ypos, color);
        OLED_SetPixel(x + xpos, y - ypos, color); OLED_SetPixel(x - xpos, y - ypos, color);
        if (d < 0) { d += b2 * ((xpos << 1) + 2) + a2 * (-(ypos << 1) + 3); xpos++; ypos--; }
        else { d += a2 * (-(ypos << 1) + 3); ypos--; }
    }
}

void OLED_DrawImage(uint8_t x, uint8_t y, const Image *img, OLED_ColorMode color) {
    uint8_t fullRow = img->h / 8, partBit = img->h % 8;
    for (uint8_t i = 0; i < img->w; i++) {
        for (uint8_t j = 0; j < fullRow; j++)
            for (uint8_t k = 0; k < 8; k++)
                if (img->data[i + j * img->w] & (1 << k))
                    OLED_SetPixel(x + i, y + j * 8 + k, color);
        if (partBit)
            for (uint8_t k = 0; k < partBit; k++)
                if (img->data[i + fullRow * img->w] & (1 << k))
                    OLED_SetPixel(x + i, y + fullRow * 8 + k, color);
    }
}

void OLED_PrintASCIIChar(uint8_t x, uint8_t y, char ch, const ASCIIFont *font, OLED_ColorMode color) {
    if (x >= 128 || y >= 64) return;
    uint8_t w = font->w, h = font->h;
    const uint8_t *data = font->chars + (ch - ' ') * ((h + 7) / 8) * w;
    for (uint8_t i = 0; i < w; i++)
        for (uint8_t j = 0; j < h; j++)
            if (data[i + (j / 8) * w] & (1 << (j % 8)))
                OLED_SetPixel(x + i, y + j, color);
}

void OLED_PrintASCIIString(uint8_t x, uint8_t y, char *str, const ASCIIFont *font, OLED_ColorMode color) {
    while (*str) { OLED_PrintASCIIChar(x, y, *str++, font, color); x += font->w; }
}

uint8_t _OLED_GetUTF8Len(char *s) {
    if ((s[0] & 0x80) == 0x00) return 1;
    else if ((s[0] & 0xE0) == 0xC0) return 2;
    else if ((s[0] & 0xF0) == 0xE0) return 3;
    else if ((s[0] & 0xF8) == 0xF0) return 4;
    return 0;
}

void OLED_PrintString(uint8_t x, uint8_t y, char *str, const Font *font, OLED_ColorMode color) {
    uint16_t i = 0;
    uint8_t oneLen = ((font->h + 7) / 8) * font->w + 4;
    while (str[i]) {
        uint8_t utf8Len = _OLED_GetUTF8Len(str + i);
        if (utf8Len == 0) break;
        uint8_t found = 0;
        for (uint8_t j = 0; j < font->len; j++) {
            const uint8_t *head = font->chars + j * oneLen;
            if (memcmp(str + i, head, utf8Len) == 0) {
                OLED_DrawImage(x, y, &(Image){font->w, font->h, head + 4}, color);
                x += font->w; i += utf8Len; found = 1; break;
            }
        }
        if (!found) {
            if (utf8Len == 1) {
                OLED_PrintASCIIChar(x, y, str[i], font->ascii, color);
                x += font->ascii->w; i++;
            } else {
                OLED_PrintASCIIChar(x, y, ' ', font->ascii, color);
                x += font->ascii->w; i += utf8Len;
            }
        }
    }
}

void OLED_ShowNumEx(uint8_t x, uint8_t y, uint32_t num, uint8_t len, const ASCIIFont *font, OLED_ColorMode color) {
    char buf[12];
    snprintf(buf, sizeof(buf), "%0*lu", len, num);
    OLED_PrintASCIIString(x, y, buf, font, color);
}

void OLED_ShowSignedNumEx(uint8_t x, uint8_t y, int32_t num, uint8_t len, const ASCIIFont *font, OLED_ColorMode color) {
    char buf[12];
    snprintf(buf, sizeof(buf), "%+*ld", len, num);
    OLED_PrintASCIIString(x, y, buf, font, color);
}

void OLED_ShowHexNumEx(uint8_t x, uint8_t y, uint32_t num, uint8_t len, const ASCIIFont *font, OLED_ColorMode color) {
    char buf[12];
    snprintf(buf, sizeof(buf), "%0*lX", len, num);
    OLED_PrintASCIIString(x, y, buf, font, color);
}

void OLED_ShowBinNumEx(uint8_t x, uint8_t y, uint32_t num, uint8_t len, const ASCIIFont *font, OLED_ColorMode color) {
    char buf[33];
    for (int i = 0; i < len; ++i) {
        buf[len - 1 - i] = (num & (1 << i)) ? '1' : '0';
    }
    buf[len] = '\0';
    OLED_PrintASCIIString(x, y, buf, font, color);
}
