/*
本代码基于江协科技 OLED 驱动代码开发，并集成了波特律动字体和图形扩展功能。  
- 江协科技代码部分：提供基础的 OLED 初始化和字符显示功能。  
- 波特律动扩展部分：添加了高级绘图函数、中文字体支持以及图形显示功能。  
如需使用中文字模或图形工具，请访问波特律动 LED 取模助手：https://led.baud-dance.com

本代码仅供学习和研究用途。未经版权所有者书面许可，不得用于任何商业用途。  
*/
#ifndef __OLED_H
#define __OLED_H

#include "stdint.h"
#include "font.h"

typedef enum {
    OLED_COLOR_NORMAL = 0,
    OLED_COLOR_REVERSED
} OLED_ColorMode;

// 江科大原有函数
void OLED_Init(void);
void OLED_Clear(void);
void OLED_ShowChar(uint8_t Line, uint8_t Column, char Char);
void OLED_ShowString(uint8_t Line, uint8_t Column, char *String);
void OLED_ShowNum(uint8_t Line, uint8_t Column, uint32_t Number, uint8_t Length);
void OLED_ShowSignedNum(uint8_t Line, uint8_t Column, int32_t Number, uint8_t Length);
void OLED_ShowHexNum(uint8_t Line, uint8_t Column, uint32_t Number, uint8_t Length);
void OLED_ShowBinNum(uint8_t Line, uint8_t Column, uint32_t Number, uint8_t Length);

// 波特律动扩展函数
void OLED_NewFrame(void);
void OLED_ShowFrame(void);
void OLED_SetPixel(uint8_t x, uint8_t y, OLED_ColorMode color);
void OLED_DrawLine(uint8_t x1, uint8_t y1, uint8_t x2, uint8_t y2, OLED_ColorMode color);
void OLED_DrawRectangle(uint8_t x, uint8_t y, uint8_t w, uint8_t h, OLED_ColorMode color);
void OLED_DrawFilledRectangle(uint8_t x, uint8_t y, uint8_t w, uint8_t h, OLED_ColorMode color);
void OLED_DrawCircle(uint8_t x, uint8_t y, uint8_t r, OLED_ColorMode color);
void OLED_DrawFilledCircle(uint8_t x, uint8_t y, uint8_t r, OLED_ColorMode color);
void OLED_DrawEllipse(uint8_t x, uint8_t y, uint8_t a, uint8_t b, OLED_ColorMode color);
void OLED_DrawImage(uint8_t x, uint8_t y, const Image *img, OLED_ColorMode color);
void OLED_PrintASCIIChar(uint8_t x, uint8_t y, char ch, const ASCIIFont *font, OLED_ColorMode color);
void OLED_PrintASCIIString(uint8_t x, uint8_t y, char *str, const ASCIIFont *font, OLED_ColorMode color);
void OLED_PrintString(uint8_t x, uint8_t y, char *str, const Font *font, OLED_ColorMode color);
//对齐江科大的显示数字函数
void OLED_ShowNumEx(uint8_t x, uint8_t y, uint32_t num, uint8_t len,const ASCIIFont *font, OLED_ColorMode color);
void OLED_ShowSignedNumEx(uint8_t x, uint8_t y, int32_t num, uint8_t len,const ASCIIFont *font, OLED_ColorMode color);
void OLED_ShowHexNumEx(uint8_t x, uint8_t y, uint32_t num, uint8_t len,const ASCIIFont *font, OLED_ColorMode color);
void OLED_ShowBinNumEx(uint8_t x, uint8_t y, uint32_t num, uint8_t len,const ASCIIFont *font, OLED_ColorMode color);

#endif
