#include "buzzer.h"
static int flag=0;
extern int delay;
static int CCR=500;
const uint16_t note[] = {0,//终止
    131, 147, 165, 175, 196, 220, 247,   // 低八度 1 2 3 4 5 6 7
    262, 294, 330, 349, 392, 440, 494,   // 中音八度 1 2 3 4 5 6 7
    523, 587, 659, 698, 784, 880, 988,    // 高八度 1 2 3 4 5 6 7
	1,//重复上一个音
	2,4,8,//二、四、八分音符标志
	3//“三分音符”
	
};

void Buzzer_Init(void){
PWM_Init();
}

void play_note(uint8_t num){

	PWM_SetCCR(CCR);
	delay=DELAY_TIME;
	
	if(note[num]==1)	return;
	
	if(num==0){
	PWM_SetCCR(0);
	//delay=ZERO_DELAY;
	return;}
	
	if(note[num]>0&&note[num]<9)//几分音符标志
	{
	flag=note[num];
	delay=0;
	return;}
	
	if(flag>0){
	delay=DELAY_TIME/flag;
	flag=0;
	}
	
	PWM_SetPSC(72000000/(ARR+1)/note[num]-1);
	//TIM_GenerateEvent(TIM2, TIM_EventSource_Update);
}
