#include "stm32f10x.h"
#include "delay.h"
#include "oled.h"
#include "song.h"
int delay=DELAY_TIME;
long num=0;

//乐谱

//长度
#define LENGTH_MYTH (sizeof(music_beautiful_myth) / sizeof(music_beautiful_myth[0]))//721

int main(){
	OLED_Init();
	Buzzer_Init();
while (1)
{
	
	play_music(num,music_beautiful_myth);
	//OLED_ShowNum(1,1,music_beautiful_myth[num],2);
	OLED_NewFrame();
	draw_tone_bar(56,num,LENGTH_MYTH);
	OLED_PrintString(24, 0, "美丽的神话", &font16x16, OLED_COLOR_NORMAL);
	OLED_PrintString(28, 28,"孙楠&韩红" , &font16x16, OLED_COLOR_NORMAL);
	OLED_ShowFrame();
	delay_ms(delay);
	

	num++;
	if(num>=LENGTH_MYTH){
	num=LENGTH_MYTH;
	}
}
}
