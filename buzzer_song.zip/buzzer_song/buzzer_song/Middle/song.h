#ifndef __SONG_H
#define __SONG_H
#include "buzzer.h"

#define INTERVAL  DELAY_TIME/100

void play_music(long note,long long * music);

void draw_tone_bar(uint8_t y,long num,long length);


extern long long music_beautiful_myth[721];
#endif
