#include <REGX51.H>
unsigned char s[]={0x01,0x02,0x04,0x08,0x10,0x20,0x40,0x80};
unsigned char count=0,num=0;

void initTimer(){
TMOD=0x01;
	TH0=(65536-50000)/256;
	TL0=(65536-50000)%256;
	ET0=1;
	EA=1;
	TR0=1;
}
void display(){
	
	P2=s[num];
	if(num==8){
	num=0;		
	}
}
void main(){

	initTimer();
	while(1)
	display();
}

void timer_isr() interrupt 1
{
	TH0=(65536-50000)/256;
	TL0=(65536-50000)%256;
	count++;
	if(count==20)
	{
		num++;
		count=0;
	}
}
