#ifndef __MAIN_H
#define __MAIN_H

#include <REGX51.H>
unsigned char s[]={0x01,0x02,0x04,0x08,0x10,0x20,0x40,0x80};
unsigned char count=0,num=0;

void initTimer();
void display();
void timer_isr() interrupt 1;
#endif 