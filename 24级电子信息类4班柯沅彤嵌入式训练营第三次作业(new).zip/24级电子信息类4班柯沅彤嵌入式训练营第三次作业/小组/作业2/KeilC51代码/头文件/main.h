#ifndef __MAIN_H
#define __MAIN_H

#include <REGX51.H>
unsigned int count=0;

void Timer0_Init();
void UART_Init();
void UART_SendChar(char ch);
void UART_SendString(char* str);
void Timer0_ISR() interrupt 1;
#endif 