#include <REGX51.H>
unsigned int count=0;

void Timer0_Init(){
	TMOD&=0xF0;
	TMOD|=0x01;
	TH0=0xFC;
	TL0=0x66;
	ET0=1;
	EA=1;
	TR0=1;
}
void UART_Init(){
	SCON=0x50;
	TMOD&=0x0F;
	TMOD|=0x20;
	TH1=0xFD;
	TL1=0xFD;
	TR1=1;
	ES=0;
}
void UART_SendChar(char ch){
SBUF=ch;
	while(!TI);
	TI=0;
}
void UART_SendString(char*str){
	while(*str){
		UART_SendChar(*str++);
	}
}
void Timer0_ISR() interrupt 1
{
	TH0=0xFC;
	TL0=0x66;
	count++;
	}
void main(){
	Timer0_Init();
	UART_Init();
	while(1){
		if(count>=1000){
			count=0;
			UART_SendString("Hello world!\r\n");
		}
}
}