#include <reg51.h>

code unsigned char seg_table[] = {
    0x3F, 0x06, 0x5B, 0x4F, 
    0x66, 0x6D, 0x7D, 0x07, 
    0x7F, 0x6F
};

unsigned char display_buffer[8] = {0}; 
unsigned char current_digit = 0;     

void UART_Init() {
    SCON = 0x50;    
    TMOD = 0x20;   
    TH1 = 0xFD;    
    TL1 = 0xFD;
    TR1 = 1;       
    ES = 1;        
    EA = 1;       
}

void Timer0_Init() {
    TMOD |= 0x01;   
    TH0 = (65536 - 2000) / 256;
    TL0 = (65536 - 2000) % 256;
    ET0 = 1;       
    TR0 = 1;       
}

void main() {
    UART_Init();
    Timer0_Init();
    while(1);      
}

unsigned char c;
void UART_ISR() interrupt 4 {
    if (RI) {
        RI = 0;     
				c = SBUF;
        if (c >= '0' && c <= '9') {
					unsigned char i=0;  
            for (; i<7; i++){
                display_buffer[i] = display_buffer[i+1];
						}
								display_buffer[7] = c - '0'; 
					P1=0x01;
        }
    }
}

void Timer0_ISR() interrupt 1 {
    TH0 = (65536 - 2000) / 256; 
    TL0 = (65536 - 2000) % 256;
  
    P2 = 0x01 << current_digit; 
		P0 = seg_table[display_buffer[current_digit]]; 
	
    current_digit = (current_digit + 1) % 8;   
}