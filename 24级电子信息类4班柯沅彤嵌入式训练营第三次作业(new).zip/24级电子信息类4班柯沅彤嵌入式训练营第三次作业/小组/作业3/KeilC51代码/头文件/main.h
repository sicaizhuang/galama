#ifndef __MAIN_H
#define __MAIN_H

#include <reg51.h>

code unsigned char seg_table[] = {
    0x3F, 0x06, 0x5B, 0x4F, 
    0x66, 0x6D, 0x7D, 0x07, 
    0x7F, 0x6F
};

unsigned char display_buffer[8] = {0}; 
unsigned char current_digit = 0;     

void UART_Init();
void Timer0_Init();
unsigned char c;
void UART_ISR() interrupt 4;
void Timer0_ISR() interrupt 1;
#endif