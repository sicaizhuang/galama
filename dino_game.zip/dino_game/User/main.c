#include "stm32f10x.h"
#include "delay.h"
#include "MPU6050.h"
#include "oled.h"
#include "dino_game.h"
#include <stdio.h>
int16_t accX, accY, accZ, gyroX, gyroY, gyroZ;
uint8_t runSerial;
uint8_t cac_speed;
uint8_t cycle_times;
int8_t  dino_y_pos;
int16_t cac_x_pos;
uint32_t score;
int main(void) {
    OLED_Init();
    MPU6050_Init();
	game_state dino_game_state=START_GAME;
 
while (1) {
	MPU6050_GetData(&accX, &accY, &accZ, &gyroX, &gyroY, &gyroZ);

	switch (dino_game_state) {
        case START_GAME:
			startGame();
		if(ifJump(accX)){
			dino_game_state=IN_GAME;
		}
			resetGameVariables();
			break;
        case IN_GAME:  
		if(ifJump(accX)&&runSerial<2){
			runSerial=2;
		}
		if(ifDie(dino_y_pos,cac_x_pos)){
			dino_game_state=RESET_GAME;
		}
			inGame();
			score++;
		
			break;
        case RESET_GAME:  
			resetGame();
			if(ifJump(accX)){
			resetGameVariables();
			dino_game_state=START_GAME;
			}
			break;
        default:         
			break;
     
    }
	delay_ms(50);      // 20 FPS
}
}
