#include "game.h"
#include "oled.h"
#include <stdio.h>
const int8_t jumpHeight[13]=
{0,11,21,28,34,37,38,37,34,28,21,11,0};


//
void drawFloor(void){
   // 第47行画实线
    OLED_DrawLine(0, FLOOR_LINE_Y, 127, FLOOR_LINE_Y, OLED_COLOR_NORMAL);

    // 第48行画虚线
    for (uint8_t x = 0; x < 128; x += 4) {
        OLED_DrawLine(x, FLOOR_LINE_Y+1, x + 1, FLOOR_LINE_Y+1, OLED_COLOR_NORMAL); // 画2像素间隔2像素
    }
}

//请输入文本
void dinoIdle(void){
OLED_DrawImage(DINO_X_POS,DINO_Y_POS,&dinoStand,OLED_COLOR_NORMAL);
OLED_PrintString(24, 10, "START GAME", &font16x16, OLED_COLOR_NORMAL);
}
//小恐龙运动动画帧序列，小恐龙的当前位置
void dinoRun(uint8_t* runSerial,int8_t *dino_y_pos)
{
	//*dino_y_pos=DINO_Y_POS;默认为恐龙的初始位置
	
	//序列为0或1时，执行奔跑逻辑，恐龙在原地踏步
if(*runSerial==0){
	OLED_DrawImage(DINO_X_POS,DINO_Y_POS,&dinoRun1,OLED_COLOR_NORMAL);
	*runSerial=1;
}
else if(*runSerial==1){
	OLED_DrawImage(DINO_X_POS,DINO_Y_POS,&dinoRun2,OLED_COLOR_NORMAL);
	*runSerial=0;
}
	//大于1，执行跳跃逻辑，分为13帧完成
else {
	//记录小恐龙当前的Y轴位置
	*dino_y_pos=DINO_Y_POS-jumpHeight[*runSerial-2];
switch (*runSerial) {
	//上升
    case 2:
		OLED_DrawImage(DINO_X_POS,DINO_Y_POS-jumpHeight[*runSerial-2],&dinoStand,OLED_COLOR_NORMAL);
        break;
    case 3:
		OLED_DrawImage(DINO_X_POS,DINO_Y_POS-jumpHeight[*runSerial-2],&dinoStand,OLED_COLOR_NORMAL);
        break;
    case 4:
		OLED_DrawImage(DINO_X_POS,DINO_Y_POS-jumpHeight[*runSerial-2],&dinoStand,OLED_COLOR_NORMAL);
        break;
    case 5:
		OLED_DrawImage(DINO_X_POS,DINO_Y_POS-jumpHeight[*runSerial-2],&dinoStand,OLED_COLOR_NORMAL);
        break;
    case 6:
		OLED_DrawImage(DINO_X_POS,DINO_Y_POS-jumpHeight[*runSerial-2],&dinoStand,OLED_COLOR_NORMAL);
        break;
    case 7:
		OLED_DrawImage(DINO_X_POS,DINO_Y_POS-jumpHeight[*runSerial-2],&dinoStand,OLED_COLOR_NORMAL);
        break;
	//最高点
    case 8:
		OLED_DrawImage(DINO_X_POS,DINO_Y_POS-jumpHeight[*runSerial-2],&dinoStand,OLED_COLOR_NORMAL);
        break;
	//下落
    case 9:
		OLED_DrawImage(DINO_X_POS,DINO_Y_POS-jumpHeight[*runSerial-2],&dinoStand,OLED_COLOR_NORMAL);
        break;
    case 10:
		OLED_DrawImage(DINO_X_POS,DINO_Y_POS-jumpHeight[*runSerial-2],&dinoStand,OLED_COLOR_NORMAL);
        break;
    case 11:
		OLED_DrawImage(DINO_X_POS,DINO_Y_POS-jumpHeight[*runSerial-2],&dinoStand,OLED_COLOR_NORMAL);
        break;
    case 12:
		OLED_DrawImage(DINO_X_POS,DINO_Y_POS-jumpHeight[*runSerial-2],&dinoStand,OLED_COLOR_NORMAL);
        break;
    case 13:
		OLED_DrawImage(DINO_X_POS,DINO_Y_POS-jumpHeight[*runSerial-2],&dinoStand,OLED_COLOR_NORMAL);
        break;
    case 14:
		OLED_DrawImage(DINO_X_POS,DINO_Y_POS-jumpHeight[*runSerial-2],&dinoStand,OLED_COLOR_NORMAL);
        break;
	default:
		break;
}
	*runSerial+=1;
	if(*runSerial>14)*runSerial=0;
}

}
//仙人掌从最右边生成，初始速度为一帧一像素，仙人掌加速周期
void cacRun(int16_t*cac_x_pos,uint8_t*cac_speed,uint8_t *cycle_times)
{
	OLED_DrawImage(*cac_x_pos,CAC_Y_POS,&cactus1,OLED_COLOR_NORMAL);
	
	*cac_x_pos-=*cac_speed;
	*cycle_times+=1;
	if(*cac_x_pos<-29)
		*cac_x_pos=127;
	if(*cycle_times%CAC_SPEED_UP==0){
	if(*cac_speed==CAC_MAX_SPEED){
	*cac_speed=CAC_MAX_SPEED;
	}
	else 
		*cac_speed+=1;
	}
}
bool ifDie(int8_t dino_y_pos,int16_t cac_x_pos){

    // X 方向有重叠：恐龙右 ≥ 仙人掌左  且  仙人掌右 ≥ 恐龙左
    bool x_overlap = (DINO_HITBOX_POS_R >= CAC_HITBOX_POS_L) &&
                     (CAC_HITBOX_POS_R >= DINO_HITBOX_POS_L);

    // Y 方向有重叠：恐龙下 ≥ 仙人掌上  且  仙人掌下 ≥ 恐龙上
    bool y_overlap = (DINO_HITBOX_POS_D >= CAC_HITBOX_POS_U) &&
                     (CAC_HITBOX_POS_D >= DINO_HITBOX_POS_U);
return x_overlap && y_overlap;
}
//死亡帧
void DIEnosaur(int8_t dino_y_pos,int16_t cac_x_pos){
	OLED_DrawImage(DINO_X_POS,dino_y_pos,&dinoDead,OLED_COLOR_NORMAL);
	OLED_DrawImage(cac_x_pos,CAC_Y_POS,&cactus1,OLED_COLOR_NORMAL);	
}
//分数/当前速度
void printScore(uint32_t score){
	char buf1[12];char buf2[12];
	sprintf(buf1, "score:%lu", (unsigned long)score);
	sprintf(buf2, "speed:%lu", (unsigned long)(cac_speed)-5);
	OLED_PrintASCIIString(128 - 6 * strlen(buf1),0, buf1, &afont8x6, OLED_COLOR_NORMAL);
	OLED_PrintASCIIString(128 - 6 * strlen(buf1),9, buf2, &afont8x6, OLED_COLOR_NORMAL);
}

//结算界面分数打印
void settlement(uint32_t score){
	OLED_DrawImage(AGAIN_X_POS,AGAIN_Y_POS,&again,OLED_COLOR_NORMAL);	
	printScore(score);
}
