#ifndef __GAME_H
#define __GAME_H

#include <stdint.h>
#include <stdbool.h>


extern uint8_t runSerial;			//动画帧序列
extern uint8_t cac_speed;			//仙人掌帧移速
extern uint8_t cycle_times;			//周期数
extern int8_t  dino_y_pos;			//
extern int16_t cac_x_pos;			//
extern uint32_t score;				//分数
#define FLOOR_LINE_Y 62  	//地面y轴坐标
#define DINO_X_POS 3 		//恐龙的横纵坐标（左上角）
#define DINO_Y_POS 38
#define CAC_Y_POS 35 		//仙人掌的Y轴坐标
#define CAC_MAX_SPEED 11 	//仙人掌每帧移动像素数
#define CAC_SPEED_UP 300 		//仙人掌加速周期
#define DINO_HITBOX_POS_L	(DINO_X_POS+4) 	//小恐龙碰撞箱,
#define DINO_HITBOX_POS_R	(DINO_X_POS+18)
#define DINO_HITBOX_POS_U	(dino_y_pos+2)	//只在函数DIEnosaur中会用到
#define DINO_HITBOX_POS_D	(dino_y_pos+24)

#define CAC_HITBOX_POS_L	(cac_x_pos+5)	//仙人掌碰撞箱
#define CAC_HITBOX_POS_R	(cac_x_pos+14)
#define CAC_HITBOX_POS_U	(CAC_Y_POS+4)
#define CAC_HITBOX_POS_D	(CAC_Y_POS+27)

#define AGAIN_X_POS 52
#define AGAIN_Y_POS 22

//y=-38/(2-a)^2*(x-a)^2+38
extern const int8_t jumpHeight[13];


void drawFloor(void);
void dinoIdle(void);
void dinoRun(uint8_t *runSerial, int8_t *dino_y_pos);
void cacRun(int16_t *cac_x_pos, uint8_t *cac_speed, uint8_t *cycle_times);
bool ifDie(int8_t dino_y_pos,int16_t cac_x_pos);
void DIEnosaur(int8_t dino_y_pos, int16_t cac_x_pos);
void printScore(uint32_t score);
void settlement(uint32_t score);

#endif
