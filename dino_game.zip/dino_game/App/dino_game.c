#include "dino_game.h"
#include "oled.h"
//默认状态
void startGame(){
	OLED_NewFrame();
	dinoIdle();
	drawFloor();
	OLED_ShowFrame();
}
//游戏中
void inGame(){
	OLED_NewFrame();
	drawFloor();
	dinoRun(&runSerial,&dino_y_pos);
	cacRun(&cac_x_pos,&cac_speed,&cycle_times);
	printScore(score);
	OLED_ShowFrame();
}
//游戏结束
void resetGame(){
	OLED_NewFrame();
	drawFloor();
	DIEnosaur(dino_y_pos,cac_x_pos);
	settlement(score);
	OLED_ShowFrame();
}
void resetGameVariables(void) {
runSerial = INIT_RUN_SERIAL;
cac_speed = INIT_CAC_SPEED;
cycle_times = INIT_CYCLE_TIMES;
dino_y_pos = INIT_DINO_Y_POS;
cac_x_pos = INIT_CAC_X_POS;
score = INIT_SCORE;
}
