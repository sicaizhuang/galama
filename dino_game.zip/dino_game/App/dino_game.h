#ifndef __DINO_GAME_H
#define __DINO_GAME_H
#include <stdint.h>
#include "game.h"

typedef enum{
	START_GAME=0,
	IN_GAME,
	RESET_GAME
}game_state;

#define MAX_ACC 2400
#define ifJump(accX)  ((accX) > MAX_ACC)

#define INIT_RUN_SERIAL 0
#define INIT_CAC_SPEED 6
#define INIT_CYCLE_TIMES 0
#define INIT_DINO_Y_POS DINO_Y_POS
#define INIT_CAC_X_POS 127
#define INIT_SCORE 0

extern game_state dino_game_state;

void startGame(void);	// 默认状态
void inGame(void);		// 游戏中
void resetGame(void);	// 游戏结束
void resetGameVariables(void);
#endif
