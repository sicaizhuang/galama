a_values = 3:20;
x_values = 2:20;
Y = zeros(length(a_values), length(x_values));

for i = 1:length(a_values)
    a = a_values(i);
    for j = 1:length(x_values)
        x = x_values(j);
        Y(i, j) = -38 / ((2 - a)^2) * (x - a)^2 + 38;
    end
end

% 创建并保存到Excel文件
xlswrite('a_x_matrix.xlsx', Y);