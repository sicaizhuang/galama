#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

// �����ջ�ڵ�ṹ
typedef struct opNode {
    char op;
    struct opNode* next;
} opNode;

typedef struct {
    opNode* top;
} opStack;

// ������ջ�ڵ�ṹ
typedef struct numNode {
    double num;
    struct numNode* next;
} numNode;

typedef struct {
    numNode* top;
} numStack;

// ��ʼ�������ջ
void initOper(opStack* s) {
    s->top = NULL;
}

// �������ջ
void pushOper(opStack* s, char op){
    opNode* node = (opNode*)malloc(sizeof(opNode));
    node->op = op;
    node->next = s->top;
    s->top = node;
}

// �������ջ
char popOper(opStack* s) {
    if (s->top == NULL) {
        fprintf(stderr, "�����ջ��\n");
        exit(EXIT_FAILURE);
    }
    opNode* temp = s->top;
    char op = temp->op;
    s->top = temp->next;
    free(temp);
    return op;
}

// �鿴ջ�������
char peekOper(opStack* s) {
    if (s->top == NULL) return '\0';
    return s->top->op;
}

// ��ʼ��������ջ
void initNum(numStack* s) {
    s->top = NULL;
}

// ��������ջ
void pushNum(numStack* s, double num) {
    numNode* node = (numNode*)malloc(sizeof(numNode));
    node->num = num;
    node->next = s->top;
    s->top = node;
}

// ��������ջ
double popNum(numStack* s) {
    if (s->top == NULL) {
        fprintf(stderr, "������ջ��\n");
        exit(EXIT_FAILURE);
    }
    numNode* temp = s->top;
    double num = temp->num;
    s->top = temp->next;
    free(temp);
    return num;
}

// ��ȡ��������ȼ�
int priolity(char op) {
    switch (op) {
    case '+':
    case '-': return 1;
    case '*':
    case '/': return 2;
    default: return 0; // ���� '('
    }
}

// �ֽ���׺����ʽΪtokens
char** tokenize(const char* expr, int* token_count) {
    char** tokens = NULL;
    int capacity = 10;
    int size = 0;
    tokens = (char**)malloc(capacity * sizeof(char*));

    int i = 0;
    while (expr[i] != '\0') {
        if (expr[i] == ' ') { // �����ո�
            i++;
            continue;
        }

        if (isdigit(expr[i])) { // ��������
            int start = i;
            while (isdigit(expr[i])) i++;
            int len = i - start;
            char* token = (char*)malloc(len + 1);
            strncpy(token, expr + start, len);
            token[len] = '\0';

            if (size >= capacity) { // ��̬����
                capacity *= 2;
                tokens = (char**)realloc(tokens, capacity * sizeof(char*));
            }
            tokens[size++] = token;
        }
        else if (strchr("+-*/()", expr[i])) { // ���������������
            char* token = (char*)malloc(2);
            token[0] = expr[i];
            token[1] = '\0';
            if (size >= capacity) {
                capacity *= 2;
                tokens = (char**)realloc(tokens, capacity * sizeof(char*));
            }
            tokens[size++] = token;
            i++;
        }
        else {
            fprintf(stderr, "��Ч�ַ�: %c\n", expr[i]);
            exit(EXIT_FAILURE);
        }
    }

    *token_count = size;
    return tokens;
}

// ��׺ת��׺
char** transfer(char** infix_tokens, int token_count, int* postfix_count) {
    opStack op_stack = { NULL };
    char** postfix = (char**)malloc(token_count * sizeof(char*));
    *postfix_count = 0;

    for (int i = 0; i < token_count; i++) {
        char* token = infix_tokens[i];
        if (isdigit(token[0])) { // ����ֱ�����
            char* new_token = strdup(token);
            postfix[(*postfix_count)++] = new_token;
        }
        else if (token[0] == '(') { // ��������ջ
            pushOper(&op_stack, '(');
        }
        else if (token[0] == ')') { // �����Ŵ���
            while (peekOper(&op_stack) != '(') {
                char* op = (char*)malloc(2);
                op[0] = popOper(&op_stack);
                op[1] = '\0';
                postfix[(*postfix_count)++] = op;
            }
            popOper(&op_stack); // ���� '('
        }
        else { // ���������
            while (op_stack.top != NULL && peekOper(&op_stack) != '(' && priolity(token[0]) <= priolity(peekOper(&op_stack))) {
                char* op = (char*)malloc(2);
                op[0] = popOper(&op_stack);
                op[1] = '\0';
                postfix[(*postfix_count)++] = op;
            }
            pushOper(&op_stack, token[0]);
        }
    }

    // ����ջ��ʣ�������
    while (op_stack.top != NULL) {
        char* op = (char*)malloc(2);
        op[0] = popOper(&op_stack);
        op[1] = '\0';
        postfix[(*postfix_count)++] = op;
    }

    return postfix;
}

// �����׺����ʽ
double evaluate(char** postfix_tokens, int token_count) {
    numStack num_stack = { NULL };
    for (int i = 0; i < token_count; i++) {
        char* token = postfix_tokens[i];
        if (isdigit(token[0])) {
            double num = atof(token);
            pushNum(&num_stack, num);//��ջ
        }
        else {
            double b = popNum(&num_stack);
            double a = popNum(&num_stack);
            switch (token[0]) {
            case '+': pushNum(&num_stack, a + b); break;
            case '-': pushNum(&num_stack, a - b); break;
            case '*': pushNum(&num_stack, a * b); break;
            case '/':
                if (b == 0) {
                    fprintf(stderr, "���󣬳���Ϊ0\n");
                    exit(EXIT_FAILURE);
                }
                pushNum(&num_stack, a / b);
                break;
            }
        }
    }
    return popNum(&num_stack);
}

// ������
int main() {
    char expr[100];
    printf("���������ʽ��");
    fgets(expr, sizeof(expr), stdin);
    expr[strcspn(expr, "\n")] = '\0'; // ȥ�����з�

    int token_count;
    char** infix_tokens = tokenize(expr, &token_count);//����ַ���

    int postfix_count;
    char** postfix_tokens = transfer(infix_tokens, token_count, &postfix_count);

    double result = evaluate(postfix_tokens, postfix_count);
    printf("�����%.2f\n", result);

    // �ͷ��ڴ�
    for (int i = 0; i < token_count; i++) free(infix_tokens[i]);
    free(infix_tokens);
    for (int i = 0; i < postfix_count; i++) free(postfix_tokens[i]);
    free(postfix_tokens);

    return 0;
}